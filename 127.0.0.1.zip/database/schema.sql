-- 创建数据库
CREATE DATABASE IF NOT EXISTS `file_management_system` DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

USE `file_management_system`;

-- 用户表
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `activate_code` varchar(64) DEFAULT NULL,
  `reset_token` varchar(64) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0 COMMENT '0=未激活, 1=已激活',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 文件权限表
CREATE TABLE IF NOT EXISTS `file_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `file_path` varchar(512) NOT NULL,
  `is_directory` tinyint(1) DEFAULT 0,
  `public_read` tinyint(1) DEFAULT 0,
  `public_write` tinyint(1) DEFAULT 0,
  `shared_users` text DEFAULT NULL,
  `shared_read` tinyint(1) DEFAULT 0,
  `shared_write` tinyint(1) DEFAULT 0,
  `inherit_permissions` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `owner_file` (`owner_id`, `file_path`(255)),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `fk_perm_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; 