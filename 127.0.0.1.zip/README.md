# PHP 文件管理系统

## 项目目标
基于 PHP 8+ 和 MVC 架构开发一个现代化的 Web 文件管理系统，实现文件浏览、上传、下载、重命名、删除等常用操作，界面美观、交互友好，支持移动端和桌面端访问。

## 功能模块
- 文件浏览（目录树、文件列表）
- 文件上传/下载
- 文件重命名/删除/新建文件夹
- 文件/目录权限管理
- 搜索与筛选
- 用户认证（可选）

## 技术栈
- 后端：PHP 8+、MVC 架构、Composer
- 前端：HTML5、CSS3（BEM/SCSS）、JavaScript（ES6+）、Bootstrap 5
- 数据库：无（基础版仅操作本地文件系统）
- 构建与工具：Git、VSCode、PHPUnit

## 目录结构
```text
├── app/
│   ├── Controller/
│   ├── Model/
│   ├── Service/
│   ├── View/
│   └── Router/
│       └── router.php
├── public/
│   ├── assets/
│   └── index.php
├── tests/
├── README.md
└── .gitignore
```

## 开发计划
1. 初始化基础MVC框架和首页
2. 实现文件浏览与基本操作
3. 优化UI与交互体验
4. 增加权限与安全机制
5. 编写测试与完善文档 

## 数据库设计
- 用户表 `users`
  - id (INT, PK, AUTO_INCREMENT)
  - username (VARCHAR[50], 唯一)
  - password (VARCHAR[255], 哈希)
  - email (VARCHAR[100], 唯一)
  - created_at (DATETIME)
  - updated_at (DATETIME)

## 入口文件
- `public/index.php`：入口文件，负责初始化和调用路由
- `app/Router/router.php`：路由解析与分发逻辑 

## 页面导航与默认行为

- 登录后默认进入仪表盘（Dashboard），展示文件统计、空间用量等信息。
- 仪表盘为主页面，侧边栏可切换至文件管理、个人设置等功能。
- 未登录用户访问首页时，显示欢迎页或登录/注册入口。 