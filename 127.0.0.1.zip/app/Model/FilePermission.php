<?php
namespace Model;

class FilePermission
{
    private $db;
    
    public function __construct()
    {
        $config = require __DIR__ . '/../Config/Database.php';
        $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset={$config['charset']}";
        $this->db = new \PDO($dsn, $config['user'], $config['pass']);
        $this->db->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $this->ensureTableExists();
    }
    
    /**
     * 确保权限表存在
     */
    private function ensureTableExists()
    {
        $sql = "CREATE TABLE IF NOT EXISTS file_permissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            owner_id INT NOT NULL,
            file_path VARCHAR(512) NOT NULL,
            is_directory TINYINT(1) DEFAULT 0,
            public_read TINYINT(1) DEFAULT 0,
            public_write TINYINT(1) DEFAULT 0,
            shared_users TEXT NULL,
            shared_read TINYINT(1) DEFAULT 0,
            shared_write TINYINT(1) DEFAULT 0,
            inherit_permissions TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY(owner_id, file_path)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        
        $this->db->exec($sql);
    }
    
    /**
     * 获取文件或文件夹的权限
     */
    public function getPermissions($ownerId, $filePath)
    {
        // 首先尝试获取指定路径的权限
        $stmt = $this->db->prepare("SELECT * FROM file_permissions WHERE owner_id = ? AND file_path = ?");
        $stmt->execute([$ownerId, $filePath]);
        $permission = $stmt->fetch();
        
        // 如果没有找到直接权限，尝试查找父目录的权限（如果设置了继承）
        if (!$permission) {
            // 分割路径获取父目录
            $parentDirs = $this->getParentDirectories($filePath);
            
            if (!empty($parentDirs)) {
                // 从最近的父目录开始查询
                foreach ($parentDirs as $parentDir) {
                    $stmt = $this->db->prepare("
                        SELECT * FROM file_permissions 
                        WHERE owner_id = ? AND file_path = ? AND is_directory = 1 AND inherit_permissions = 1
                    ");
                    $stmt->execute([$ownerId, $parentDir]);
                    $permission = $stmt->fetch();
                    
                    if ($permission) {
                        // 找到可继承的父目录权限
                        return $permission;
                    }
                }
            }
            
            // 如果没有权限记录，返回默认权限
            return $this->getDefaultPermissions($ownerId, $filePath);
        }
        
        return $permission;
    }
    
    /**
     * 获取父目录列表
     */
    private function getParentDirectories($path)
    {
        $parents = [];
        $path = rtrim($path, '/\\');
        $maxLevels = 10; // 最多处理10层目录
        $level = 0;
        
        while ($path = dirname($path)) {
            if ($path == '.' || $path == '/' || empty($path) || $level >= $maxLevels) {
                break;
            }
            $parents[] = $path;
            $level++;
        }
        
        return $parents;
    }
    
    /**
     * 获取默认权限
     */
    private function getDefaultPermissions($ownerId, $filePath)
    {
        $isDir = is_dir($filePath) ? 1 : 0;
        
        return [
            'id' => null,
            'owner_id' => $ownerId,
            'file_path' => $filePath,
            'is_directory' => $isDir,
            'public_read' => 0,
            'public_write' => 0,
            'shared_users' => null,
            'shared_read' => 0,
            'shared_write' => 0,
            'inherit_permissions' => 1,
        ];
    }
    
    /**
     * 设置文件或文件夹的权限
     */
    public function setPermissions($ownerId, $filePath, $permissions, $isDir = 0)
    {
        // 检查是否已有此文件的权限设置
        $stmt = $this->db->prepare("SELECT id FROM file_permissions WHERE owner_id = ? AND file_path = ?");
        $stmt->execute([$ownerId, $filePath]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            // 更新现有权限
            $sql = "UPDATE file_permissions SET 
                public_read = ?, 
                public_write = ?, 
                shared_users = ?, 
                shared_read = ?, 
                shared_write = ?, 
                inherit_permissions = ?,
                is_directory = ?
                WHERE id = ?";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $permissions['public_read'] ? 1 : 0,
                $permissions['public_write'] ? 1 : 0,
                $permissions['shared_users'] ?? null,
                $permissions['shared_read'] ? 1 : 0,
                $permissions['shared_write'] ? 1 : 0,
                $permissions['inherit'] ? 1 : 0,
                $isDir ? 1 : 0,
                $existing['id']
            ]);
        } else {
            // 插入新权限
            $sql = "INSERT INTO file_permissions 
                (owner_id, file_path, is_directory, public_read, public_write, shared_users, shared_read, shared_write, inherit_permissions) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $ownerId,
                $filePath,
                $isDir ? 1 : 0,
                $permissions['public_read'] ? 1 : 0,
                $permissions['public_write'] ? 1 : 0,
                $permissions['shared_users'] ?? null,
                $permissions['shared_read'] ? 1 : 0,
                $permissions['shared_write'] ? 1 : 0,
                $permissions['inherit'] ? 1 : 0
            ]);
        }
        
        return true;
    }
    
    /**
     * 检查用户是否有权限访问文件
     * 
     * @param int $currentUserId 当前访问用户ID
     * @param int $ownerId 文件所有者ID
     * @param string $filePath 文件路径
     * @param string $permission 权限类型(read/write)
     * @return bool
     */
    public function checkPermission($currentUserId, $ownerId, $filePath, $permission = 'read')
    {
        // 如果是所有者，则有全部权限
        if ($currentUserId === $ownerId) {
            return true;
        }
        
        // 获取文件权限
        $perms = $this->getPermissions($ownerId, $filePath);
        
        if (!$perms) {
            return false;
        }
        
        // 检查公开权限
        if ($permission === 'read' && $perms['public_read']) {
            return true;
        }
        
        if ($permission === 'write' && $perms['public_write']) {
            return true;
        }
        
        // 检查是否是共享用户
        if ($perms['shared_users']) {
            // 加载当前用户
            $userModel = new User();
            $currentUser = $userModel->getUserById($currentUserId);
            
            if ($currentUser) {
                $sharedEmails = array_map('trim', explode(',', $perms['shared_users']));
                
                if (in_array($currentUser['email'], $sharedEmails)) {
                    if ($permission === 'read' && $perms['shared_read']) {
                        return true;
                    }
                    
                    if ($permission === 'write' && $perms['shared_write']) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * 删除文件或目录的权限
     */
    public function deletePermissions($ownerId, $filePath)
    {
        $stmt = $this->db->prepare("DELETE FROM file_permissions WHERE owner_id = ? AND file_path = ?");
        return $stmt->execute([$ownerId, $filePath]);
    }
} 