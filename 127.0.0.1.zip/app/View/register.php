<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册新账号 - Littlemole 文件管理系统</title>
    <link href="https://cdnjs.loli.net/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body { background: #f6f8fa; }
        .hero {
            background: #1976d2;
            color: #fff;
            padding: 0.75rem 0;
        }
        .hero-title {
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .hero-nav {
            font-size: 1rem;
        }
        .register-card {
            max-width: 400px;
            margin: 60px auto 0 auto;
            box-shadow: 0 4px 24px rgba(25,118,210,0.10);
            border-radius: 18px;
            background: #fff;
            padding: 2.5rem 2rem 2rem 2rem;
            position: relative;
            opacity: 0;
            transform: translateY(40px);
            animation: fadeInUp 0.8s cubic-bezier(.23,1.01,.32,1) 0.1s forwards;
        }
        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: none;
            }
        }
        .register-illustration {
            display: block;
            margin: 0 auto 1.2rem auto;
            max-width: 120px;
            height: auto;
            opacity: 0;
            transform: scale(0.9);
            animation: fadeInSvg 0.8s cubic-bezier(.23,1.01,.32,1) 0.5s forwards;
        }
        @keyframes fadeInSvg {
            to {
                opacity: 1;
                transform: none;
            }
        }
        .register-title {
            font-weight: 700;
            font-size: 1.5rem;
            color: #1976d2;
            margin-bottom: 1.2rem;
            text-align: center;
        }
        .form-label { font-weight: 500; }
        .btn-primary { background: #1976d2; border: none; }
        .btn-primary:hover { background: #125ea7; }
        .register-links { text-align: center; margin-top: 1.2rem; }
        .register-links a { margin: 0 0.5rem; }
        @media (max-width: 500px) {
            .register-card { padding: 1.2rem 0.5rem; max-width: 98vw; }
            .register-illustration { max-width: 80px; }
            .register-title { font-size: 1.1rem; }
        }
        @media (max-width: 350px) {
            .register-card { padding: 0.5rem 0.1rem; }
        }
    </style>
</head>
<body>
    <div class="hero d-flex justify-content-between align-items-center px-4">
        <div class="hero-title">Littlemole 文件管理系统</div>
        <div class="hero-nav">
            <a href="?c=Auth&a=login" class="text-white text-decoration-none me-3"><i class="bi bi-box-arrow-in-right"></i> 登录</a>
        </div>
    </div>
    <div class="container">
        <div class="register-card mt-5">
            <!-- 科技感SVG插画 -->
            <svg class="register-illustration" width="120" height="80" viewBox="0 0 120 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="10" y="30" width="100" height="40" rx="10" fill="#E3F2FD"/>
                <rect x="20" y="40" width="80" height="20" rx="6" fill="#90CAF9"/>
                <rect x="35" y="50" width="50" height="8" rx="4" fill="#1976D2"/>
                <rect x="35" y="62" width="20" height="4" rx="2" fill="#1976D2" opacity="0.5"/>
                <rect x="65" y="62" width="18" height="4" rx="2" fill="#1976D2" opacity="0.3"/>
                <rect x="45" y="18" width="30" height="14" rx="4" fill="#1976D2" opacity="0.7"/>
                <rect x="55" y="24" width="10" height="4" rx="2" fill="#fff" opacity="0.7"/>
            </svg>
            <div class="register-title">注册新账号</div>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"> <?= htmlspecialchars($error) ?> </div>
            <?php endif; ?>
            <form method="post" autocomplete="off" id="register-form">
                <div class="mb-3">
                    <label for="username" class="form-label">用户名</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">邮箱</label>
                    <div class="input-group">
                        <input type="email" class="form-control" id="email" name="email" required>
                        <button type="button" class="btn btn-outline-primary" id="send-code-btn" style="min-width:110px;">发送验证码</button>
                    </div>
                    <div class="d-flex align-items-center mt-2">
                        <input type="text" class="form-control me-2" style="max-width:120px;" id="email_code" name="email_code" placeholder="验证码" required>
                        <input type="text" class="form-control me-2" style="max-width:80px;" id="captcha" name="captcha" placeholder="图形码" required>
                        <img src="?c=Auth&a=captcha" id="captcha-img" alt="验证码" style="height:36px;cursor:pointer;border-radius:6px;" title="看不清换一张">
                    </div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">密码</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                    <div class="form-text">密码长度不少于6位</div>
                </div>
                <button type="submit" class="btn btn-primary w-100">注册</button>
            </form>
            <div class="register-links">
                <a href="?c=Auth&a=login">已有账号？登录</a>
            </div>
        </div>
    </div>
    <script>
    let timer = null;
    let count = 0;
    const btn = document.getElementById('send-code-btn');
    const emailInput = document.getElementById('email');
    btn.onclick = function() {
        if (btn.disabled) return;
        const email = emailInput.value.trim();
        if (!email) { alert('请填写邮箱'); return; }
        btn.disabled = true;
        btn.innerText = '发送中...';
        fetch('?c=Auth&a=sendEmailCode', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'email=' + encodeURIComponent(email)
        }).then(r => r.json()).then(res => {
            if (res.success) {
                count = 120;
                btn.innerText = count + '秒后重发';
                timer = setInterval(() => {
                    count--;
                    btn.innerText = count + '秒后重发';
                    if (count <= 0) {
                        clearInterval(timer);
                        btn.disabled = false;
                        btn.innerText = '发送验证码';
                    }
                }, 1000);
            } else {
                alert(res.message || '发送失败');
                btn.disabled = false;
                btn.innerText = '发送验证码';
            }
        }).catch(() => {
            alert('网络错误');
            btn.disabled = false;
            btn.innerText = '发送验证码';
        });
    };
    document.getElementById('captcha-img').onclick = function() {
        this.src = '?c=Auth&a=captcha&' + Math.random();
    };
    </script>
</body>
</html> 