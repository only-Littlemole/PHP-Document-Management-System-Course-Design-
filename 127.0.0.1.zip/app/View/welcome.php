<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Littlemole 文件管理系统</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body { background: #f6f8fa; }
        .hero {
            background: #1976d2;
            color: #fff;
            padding: 0.75rem 0;
        }
        .hero-title {
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .hero-nav {
            font-size: 1rem;
        }
        .main-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-top: 2.5rem;
            margin-bottom: 1rem;
            color: #1976d2;
        }
        .main-subtitle {
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 2.5rem;
        }
        .feature-card {
            border: none;
            box-shadow: 0 2px 12px rgba(25, 118, 210, 0.06);
            border-radius: 16px;
            transition: box-shadow 0.2s;
            min-height: 220px;
        }
        .feature-card:hover {
            box-shadow: 0 4px 24px rgba(25, 118, 210, 0.12);
        }
        .feature-icon {
            font-size: 2.5rem;
            color: #1976d2;
            margin-bottom: 1rem;
        }
        .why-list li {
            margin-bottom: 0.5rem;
            font-size: 1.08rem;
        }
        .why-list .bi {
            color: #43a047;
            margin-right: 0.5rem;
        }
        .welcome-btns .btn {
            min-width: 120px;
            font-size: 1.1rem;
        }
        @media (max-width: 767px) {
            .main-title { font-size: 1.5rem; }
            .feature-card { min-height: 180px; }
        }
    </style>
</head>
<body>
    <div class="hero d-flex justify-content-between align-items-center px-4">
        <div class="hero-title">Littlemole 文件管理系统</div>
        <div class="hero-nav">
            <a href="?c=Auth&a=login" class="text-white text-decoration-none me-3"><i class="bi bi-box-arrow-in-right"></i> 登录</a>
            <a href="?c=Auth&a=register" class="text-white text-decoration-none"><i class="bi bi-person-plus"></i> 注册</a>
        </div>
    </div>
    <div class="container">
        <div class="text-center">
            <div class="main-title">Littlemole 文件管理系统</div>
            <div class="main-subtitle">安全、高效的文件存储与管理解决方案</div>
        </div>
        <div class="row g-4 justify-content-center mb-5">
            <div class="col-12 col-md-4">
                <div class="card feature-card text-center p-4 h-100">
                    <div class="feature-icon"><i class="bi bi-shield-lock"></i></div>
                    <h5 class="fw-bold mb-2">安全存储</h5>
                    <div class="text-muted">采用先进的加密技术和权限控制，确保您的文件安全无忧。</div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="card feature-card text-center p-4 h-100">
                    <div class="feature-icon"><i class="bi bi-share"></i></div>
                    <h5 class="fw-bold mb-2">便捷分享</h5>
                    <div class="text-muted">轻松分享文件给他人，控制访问权限和有效期限。</div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="card feature-card text-center p-4 h-100">
                    <div class="feature-icon"><i class="bi bi-phone"></i></div>
                    <h5 class="fw-bold mb-2">随时访问</h5>
                    <div class="text-muted">响应式设计，在任何设备上都能流畅访问和管理您的文件。</div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mb-4 align-items-center">
            <div class="col-12 col-md-6 col-lg-5">
                <h4 class="fw-bold mb-3">为什么选择我们?</h4>
                <ul class="why-list list-unstyled mb-4">
                    <li><i class="bi bi-check-circle-fill"></i> 高级加密保护您的敏感文件</li>
                    <li><i class="bi bi-check-circle-fill"></i> 强大的文件组织和搜索功能</li>
                    <li><i class="bi bi-check-circle-fill"></i> 自动版本控制和历史记录</li>
                    <li><i class="bi bi-check-circle-fill"></i> 细粒度的访问控制和权限设置</li>
                    <li><i class="bi bi-check-circle-fill"></i> 简洁直观的用户界面</li>
                </ul>
                <div class="welcome-btns d-flex flex-wrap gap-3 justify-content-center justify-content-md-start">
                    <a href="?c=Auth&a=register" class="btn btn-primary px-4">立即注册</a>
                    <a href="?c=Auth&a=login" class="btn btn-outline-primary px-4">登录</a>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-5 d-none d-md-block text-center">
                <!-- 更高的科技感SVG插画：文件管理云端主题 -->
                <svg width="240" height="260" viewBox="0 0 240 260" fill="none" xmlns="http://www.w3.org/2000/svg" style="max-width:320px;width:100%;height:auto;">
                  <defs>
                    <linearGradient id="cloud" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stop-color="#90caf9"/>
                      <stop offset="100%" stop-color="#e3f2fd"/>
                    </linearGradient>
                  </defs>
                  <ellipse cx="120" cy="200" rx="90" ry="30" fill="#e3f2fd"/>
                  <ellipse cx="120" cy="180" rx="70" ry="22" fill="#bbdefb"/>
                  <rect x="40" y="60" width="160" height="90" rx="16" fill="url(#cloud)"/>
                  <rect x="60" y="80" width="120" height="50" rx="8" fill="#1976d2" opacity="0.12"/>
                  <rect x="70" y="100" width="100" height="16" rx="4" fill="#1976d2" opacity="0.5"/>
                  <rect x="70" y="122" width="60" height="8" rx="4" fill="#1976d2" opacity="0.3"/>
                  <rect x="135" y="122" width="30" height="8" rx="4" fill="#1976d2" opacity="0.2"/>
                  <rect x="90" y="40" width="60" height="30" rx="8" fill="#1976d2" opacity="0.7"/>
                  <rect x="110" y="50" width="20" height="10" rx="3" fill="#fff" opacity="0.7"/>
                  <rect x="100" y="170" width="40" height="16" rx="4" fill="#1976d2" opacity="0.7"/>
                  <rect x="110" y="180" width="20" height="6" rx="2" fill="#fff" opacity="0.7"/>
                  <circle cx="180" cy="90" r="10" fill="#1976d2" opacity="0.5"/>
                  <rect x="190" y="90" width="12" height="5" rx="2.5" fill="#1976d2" opacity="0.5"/>
                  <rect x="50" y="90" width="12" height="5" rx="2.5" fill="#1976d2" opacity="0.5"/>
                  <circle cx="60" cy="90" r="6" fill="#1976d2" opacity="0.3"/>
                </svg>
            </div>
        </div>
    </div>
</body>
</html> 