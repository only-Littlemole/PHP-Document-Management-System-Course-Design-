<?php ob_start(); ?>
<div class="row g-4 mb-4">
    <div class="col-12 col-md-4">
        <div class="card shadow-sm border-0 text-center p-4">
            <div class="mb-2"><i class="bi bi-folder2-open" style="font-size:2rem;color:#1976d2;"></i></div>
            <div class="fs-4 fw-bold"><?= $stats['file_count'] ?></div>
            <div class="text-muted">文件总数</div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="card shadow-sm border-0 text-center p-4">
            <div class="mb-2"><i class="bi bi-people" style="font-size:2rem;color:#1976d2;"></i></div>
            <div class="fs-4 fw-bold"><?= $stats['user_count'] ?></div>
            <div class="text-muted">用户总数</div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="card shadow-sm border-0 text-center p-4">
            <div class="mb-2"><i class="bi bi-hdd-network" style="font-size:2rem;color:#1976d2;"></i></div>
            <div class="fs-4 fw-bold"><?= number_format($stats['total_size']/1024/1024,2) ?> MB</div>
            <div class="text-muted">空间用量</div>
        </div>
    </div>
</div>
<div class="card border-0 shadow-sm p-4">
    <h5 class="fw-bold mb-3">欢迎使用 Littlemole 文件管理系统！</h5>
    <ul class="mb-0 text-muted">
        <li>左侧可切换"仪表盘"、"文件管理"、"用户中心"等功能模块</li>
        <li>仪表盘展示系统统计和快捷入口</li>
        <li>文件管理支持浏览、上传、下载、重命名、删除等操作</li>
        <li>后续可扩展更多功能，欢迎提出建议！</li>
    </ul>
</div>
<?php $content = ob_get_clean(); include __DIR__ . '/layout.php'; ?> 