<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>文件管理系统</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/quill/1.3.7/quill.snow.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .file-table th, .file-table td { vertical-align: middle; }
        .file-icon { width: 24px; height: 24px; margin-right: 8px; }
        .table td[style*="white-space:nowrap"] .btn { margin-right: 2px; margin-left: 0; }
        .table td[style*="white-space:nowrap"] .btn:last-child { margin-right: 0; }
        .file-link { color: #1976d2; text-decoration: none; font-weight: 500; transition: color 0.2s; }
        .file-link:hover { color: #125ea7; text-decoration: underline; }
        .breadcrumb { background: none; padding: 0; margin-bottom: 0; }
    </style>
</head>
<body>
<div class="container py-4">
    <?php
    // 初始化权限模型
    try {
        $permModel = new \Model\FilePermission();
    } catch (\Exception $e) {
        $permModel = null;
    }
    
    // 计算面包屑路径及跳转链接
    $relativePath = ltrim(str_replace($realUserRoot, '', $realDir), '/\\');
    $breadcrumb = [];
    $breadcrumbLinks = [];
    $breadcrumbDirs = [];
    $breadcrumb[] = ['name' => '根目录', 'dir' => $userRoot];
    $breadcrumbLinks[] = $userRoot;
    $breadcrumbDirs[] = $userRoot;
    if ($relativePath !== '' && $relativePath !== false) {
        $parts = explode(DIRECTORY_SEPARATOR, trim($relativePath, '/\\'));
        $accum = $userRoot;
        foreach ($parts as $p) {
            if ($p !== '') {
                $accum .= DIRECTORY_SEPARATOR . $p;
                $breadcrumb[] = ['name' => $p, 'dir' => $accum];
                $breadcrumbLinks[] = $accum;
                $breadcrumbDirs[] = $accum;
            }
        }
    }
    // 上一级目录
    $parentDir = dirname($realDir);
    if (strpos($parentDir, $realUserRoot) !== 0) $parentDir = $realUserRoot;
    ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="d-flex align-items-center">
            <button class="btn btn-outline-secondary btn-sm me-2" onclick="location.href='?c=File&a=index&dir=<?= urlencode($parentDir) ?>'" <?= $realDir === $realUserRoot ? 'disabled' : '' ?> title="上一级"><i class="bi bi-arrow-left"></i></button>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <?php foreach ($breadcrumb as $i => $item): ?>
                        <li class="breadcrumb-item<?= $i === count($breadcrumb)-1 ? ' active' : '' ?>" <?= $i === count($breadcrumb)-1 ? 'aria-current="page"' : '' ?>>
                            <?php if ($i !== count($breadcrumb)-1): ?>
                                <a href="?c=File&a=index&dir=<?= urlencode($item['dir']) ?>" class="file-link"> <?= htmlspecialchars($item['name']) ?> </a>
                            <?php else: ?>
                                <?= htmlspecialchars($item['name']) ?>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ol>
            </nav>
        </div>
        <div>
            <button class="btn btn-outline-primary btn-sm me-2" id="inlineMkdirBtn"><i class="bi bi-folder-plus"></i> 新建文件夹</button>
            <button class="btn btn-outline-info btn-sm me-2" id="inlineCreateFileBtn"><i class="bi bi-file-earmark-plus"></i> 新建文件</button>
            <button class="btn btn-outline-success btn-sm me-2" onclick="document.getElementById('uploadInput').click();"><i class="bi bi-upload"></i> 上传文件</button>
            <button class="btn btn-outline-secondary btn-sm" id="multiSelectBtn"><i class="bi bi-check2-square"></i> 多选</button>
            <form id="uploadForm" method="post" enctype="multipart/form-data" action="?c=File&a=upload" style="display:none;">
                <input type="hidden" name="dir" value="<?= htmlspecialchars($dir) ?>">
                <input type="file" name="file" id="uploadInput" onchange="if(this.files.length){document.getElementById('uploadForm').submit();}">
            </form>
        </div>
    </div>
    <div id="batchBar" class="mb-2" style="display:none;">
        <button class="btn btn-danger btn-sm me-2" id="batchDelete"><i class="bi bi-trash"></i> 批量删除</button>
        <button class="btn btn-secondary btn-sm me-2" id="batchCopy"><i class="bi bi-files"></i> 复制</button>
        <button class="btn btn-secondary btn-sm me-2" id="batchCut"><i class="bi bi-scissors"></i> 剪切</button>
        <button class="btn btn-primary btn-sm" id="batchPaste" style="display:none;"><i class="bi bi-clipboard-check"></i> 粘贴</button>
        <span class="text-muted ms-3" id="batchCount"></span>
        <button class="btn btn-link btn-sm ms-2" id="multiSelectCancel">取消多选</button>
    </div>
    <?php if (!empty($message)): ?>
        <div class="alert alert-info py-2"> <?= htmlspecialchars($message) ?> </div>
    <?php endif; ?>
    <table class="table table-hover align-middle">
        <thead class="table-light">
        <tr>
            <th id="multiSelectTh" style="width:36px;display:none;"><input type="checkbox" id="multiSelectAll"></th>
            <th>名称</th>
            <th>类型</th>
            <th>大小</th>
            <th>修改时间</th>
            <th style="min-width:80px;white-space:nowrap;">权限</th>
            <th style="min-width:160px;white-space:nowrap;">操作</th>
        </tr>
        </thead>
        <tbody id="fileTableBody">
        <?php if (empty($fileList)): ?>
            <tr><td colspan="7" class="text-center text-muted">暂无文件或文件夹</td></tr>
        <?php endif; ?>
        <?php foreach ($fileList as $file):
            $filePath = $realDir . DIRECTORY_SEPARATOR . $file;
            $isDir = is_dir($filePath);
            // 生成文件在user_files目录下的相对路径
            $pos = strpos($filePath, 'user_files');
            if ($pos !== false) {
                $relativePath = str_replace('\\', '/', substr($filePath, $pos));
                // 通过FileAccess控制器访问
                $webPath = "?c=FileAccess&a=getFile&path=" . urlencode($relativePath);
                // 下载链接增加download参数
                $downloadPath = $webPath . "&download=1";
            } else {
                $webPath = '';
                $downloadPath = '';
            }
            $editableExts = ['txt','md','log','json','js','css','php','html','xml','csv'];
            $fileExt = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        ?>
            <tr class="file-row" data-file="<?= htmlspecialchars(addslashes($webPath)) ?>" data-dir="<?= htmlspecialchars(addslashes($filePath)) ?>" data-name="<?= htmlspecialchars(addslashes($file)) ?>" data-isdir="<?= $isDir ? '1' : '0' ?>">
                <td class="multiSelectTd" style="display:none;"><input type="checkbox" class="multiSelectCk" value="<?= htmlspecialchars($filePath) ?>"></td>
                <td>
                    <?php if ($isDir): ?>
                        <i class="bi bi-folder2-open text-warning me-1"></i>
                        <a href="?c=File&a=index&dir=<?= urlencode($filePath) ?>" class="file-link"> <?= htmlspecialchars($file) ?> </a>
                    <?php else: ?>
                        <i class="bi bi-file-earmark text-secondary me-1"></i>
                        <?= htmlspecialchars($file) ?>
                    <?php endif; ?>
                </td>
                <td><?= $isDir ? '文件夹' : '文件' ?></td>
                <td><?= $isDir ? '-' : number_format(filesize($filePath)/1024, 2) . ' KB' ?></td>
                <td><?= date('Y-m-d H:i:s', filemtime($filePath)) ?></td>
                <td>
                    <?php
                    try {
                        // 获取文件权限
                        if ($permModel) {
                            $perms = $permModel->getPermissions($_SESSION['user']['id'], $filePath);
                            if ($perms['public_read'] || $perms['public_write'] || !empty($perms['shared_users'])):
                            ?>
                            <div class="d-flex align-items-center">
                                <?php if ($perms['public_read']): ?>
                                    <span class="badge bg-success me-1" title="公开可读"><i class="bi bi-eye"></i></span>
                                <?php endif; ?>
                                <?php if ($perms['public_write']): ?>
                                    <span class="badge bg-warning text-dark me-1" title="公开可写"><i class="bi bi-pencil"></i></span>
                                <?php endif; ?>
                                <?php if (!empty($perms['shared_users'])): ?>
                                    <span class="badge bg-info me-1" title="已共享"><i class="bi bi-people"></i></span>
                                <?php endif; ?>
                            </div>
                            <?php else: ?>
                                <span class="text-muted">私有</span>
                            <?php endif;
                        } else {
                            echo '<span class="text-muted">未知</span>';
                        }
                    } catch (\Exception $e) {
                        echo '<span class="text-danger" title="' . htmlspecialchars($e->getMessage()) . '">错误</span>';
                    }
                    ?>
                </td>
                <td style="white-space:nowrap;">
                    <?php if (!$isDir): ?>
                        <a href="<?= htmlspecialchars($downloadPath) ?>" class="btn btn-link btn-sm p-1 op-btn" title="下载"><i class="bi bi-download"></i></a>
                        <button class="btn btn-link btn-sm text-info p-1 op-btn" onclick="previewFile('<?= htmlspecialchars(addslashes($webPath)) ?>','<?= htmlspecialchars(addslashes($file)) ?>')" title="预览"><i class="bi bi-eye"></i></button>
                    <?php endif; ?>
                    <button class="btn btn-link btn-sm text-secondary p-1 op-btn" onclick="showPermissions('<?= htmlspecialchars(addslashes($filePath)) ?>','<?= htmlspecialchars(addslashes($file)) ?>','<?= $isDir ? '1' : '0' ?>')" title="权限设置"><i class="bi bi-shield-lock"></i></button>
                    <button class="btn btn-link btn-sm text-primary p-1 op-btn" onclick="showRename('<?= htmlspecialchars(addslashes($filePath)) ?>','<?= htmlspecialchars(addslashes($file)) ?>')" title="重命名"><i class="bi bi-pencil"></i></button>
                    <form method="post" action="?c=File&a=delete" style="display:inline;" onsubmit="return confirm('确定要删除吗？');">
                        <input type="hidden" name="path" value="<?= htmlspecialchars($filePath) ?>">
                        <button type="submit" class="btn btn-link btn-sm text-danger p-1 op-btn" title="删除"><i class="bi bi-trash"></i></button>
                    </form>
                    <?php if (!$isDir && in_array($fileExt, $editableExts)): ?>
                        <button class="btn btn-link btn-sm text-warning p-1 op-btn" onclick="editFile('<?= htmlspecialchars(addslashes($filePath)) ?>','<?= htmlspecialchars(addslashes($file)) ?>')" title="编辑"><i class="bi bi-pencil-square"></i></button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <!-- 重命名 Modal -->
    <div class="modal fade" id="renameModal" tabindex="-1" aria-labelledby="renameModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <form class="modal-content" method="post" action="?c=File&a=rename">
          <div class="modal-header">
            <h5 class="modal-title" id="renameModalLabel">重命名</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="path" id="renamePath">
            <input type="text" class="form-control" name="new_name" id="renameNewName" placeholder="新名称" required maxlength="50">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="submit" class="btn btn-primary">确定</button>
          </div>
        </form>
      </div>
    </div>
    <!-- 预览 Modal -->
    <div class="modal fade" id="previewModal" tabindex="-1" aria-labelledby="previewModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="previewModalLabel">文件预览</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" id="previewBody" style="min-height:300px;text-align:center;"></div>
        </div>
      </div>
    </div>
    <!-- 编辑文件 Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editModalLabel">编辑文件：<span id="editFileName"></span></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="关闭"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" id="editFilePath">
            <!-- 富文本编辑器容器 -->
            <div id="quillEditor" style="display:none;">
              <div id="quillToolbar"></div>
              <div id="quillContent" style="height:300px;"></div>
            </div>
            <!-- 纯文本编辑器容器 -->
            <textarea class="form-control" id="editFileContent" rows="16" style="font-family:monospace;display:none;"></textarea>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="button" class="btn btn-primary" id="editFileSave">保存</button>
          </div>
        </div>
      </div>
    </div>
    <!-- 权限设置 Modal -->
    <div class="modal fade" id="permissionsModal" tabindex="-1" aria-labelledby="permissionsModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <form class="modal-content" method="post" action="?c=File&a=setPermissions">
          <div class="modal-header">
            <h5 class="modal-title" id="permissionsModalLabel">权限设置</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="path" id="permissionsPath">
            <input type="hidden" name="isDir" id="permissionsIsDir">
            <p id="permissionsFileName" class="mb-3 fw-bold"></p>
            
            <div class="mb-2">
              <span class="fw-bold">访问权限：</span>
            </div>
            
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="permPublicReadable" name="permissions[public_read]" value="1">
              <label class="form-check-label" for="permPublicReadable">
                <i class="bi bi-globe me-1"></i> 公开可读
                <small class="text-muted d-block">允许任何人读取此文件/文件夹内容</small>
              </label>
            </div>
            
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="permPublicWritable" name="permissions[public_write]" value="1">
              <label class="form-check-label" for="permPublicWritable">
                <i class="bi bi-pencil-square me-1"></i> 公开可写
                <small class="text-muted d-block">允许任何人修改此文件/文件夹内容</small>
              </label>
            </div>
            
            <hr class="my-3">
            
            <div class="mb-2">
              <span class="fw-bold">共享设置：</span>
            </div>
            
            <div class="mb-3">
              <label for="permSharedUsers" class="form-label">共享给特定用户(以邮箱分隔)</label>
              <input type="text" class="form-control" id="permSharedUsers" name="permissions[shared_users]" placeholder="user1@example.com, user2@example.com">
              <small class="text-muted">多个用户请用逗号分隔</small>
            </div>
            
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="permShareReadable" name="permissions[shared_read]" value="1">
              <label class="form-check-label" for="permShareReadable">
                <i class="bi bi-people me-1"></i> 共享用户可读
              </label>
            </div>
            
            <div class="form-check mb-2">
              <input class="form-check-input" type="checkbox" id="permShareWritable" name="permissions[shared_write]" value="1">
              <label class="form-check-label" for="permShareWritable">
                <i class="bi bi-people-fill me-1"></i> 共享用户可写
              </label>
            </div>
            
            <div class="form-check mb-3">
              <input class="form-check-input" type="checkbox" id="permInherit" name="permissions[inherit]" value="1">
              <label class="form-check-label" for="permInherit">
                <i class="bi bi-diagram-3 me-1"></i> 子文件夹继承权限
                <small class="text-muted d-block">如果是文件夹，其下所有文件和子文件夹将继承此权限</small>
              </label>
            </div>
            
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="submit" class="btn btn-primary">保存</button>
          </div>
        </form>
      </div>
    </div>
    <!-- Bootstrap 5 JS，必须在自定义脚本之前 -->
    <script src="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.bootcdn.net/ajax/libs/quill/1.3.7/quill.min.js"></script>
    <script>
    function showRename(path, name) {
        document.getElementById('renamePath').value = path;
        document.getElementById('renameNewName').value = name;
        var modal = new bootstrap.Modal(document.getElementById('renameModal'));
        modal.show();
    }
    function previewFile(path, name) {
        console.log('预览文件路径:', path); // 调试输出
        console.log('预览文件名称:', name); // 调试输出
        const ext = name.split('.').pop().toLowerCase();
        let html = '';
        if (["png","jpg","jpeg","gif","bmp","webp"].includes(ext)) {
            // 确保图片加载时显示加载状态
            html = `<div class="text-center mb-2">加载中...</div>
                   <img src="${path}" alt="图片预览" style="max-width:100%;max-height:60vh;" 
                   onload="this.previousElementSibling.style.display='none';"
                   onerror="this.style.display='none';this.previousElementSibling.innerHTML='<div class=\\'text-danger\\'>图片加载失败</div><div class=\\'text-muted small mt-2\\'>路径: ${path}</div>';">`;
        } else if (["txt","md","log","json","js","css","php","html","xml","csv"].includes(ext)) {
            fetch(path).then(r=>r.text()).then(t=>{
                document.getElementById('previewBody').innerHTML = `<pre style='text-align:left;max-height:60vh;overflow:auto;background:#f8f9fa;padding:1em;border-radius:8px;'>`+t.replace(/</g,'&lt;')+`</pre>`;
            }).catch(err => {
                document.getElementById('previewBody').innerHTML = `<div class="alert alert-danger">加载失败: ${err.message}</div>
                                                                  <div class="text-muted small">路径: ${path}</div>`;
            });
            html = '加载中...';
        } else if (["pdf"].includes(ext)) {
            html = `<iframe src="${path}" style="width:100%;height:60vh;border:none;" 
                   onload="console.log('PDF加载成功')" 
                   onerror="this.style.display='none';document.getElementById('previewBody').innerHTML='<div class=\\'alert alert-danger\\'>PDF加载失败</div><div class=\\'text-muted small\\'>路径: ${path}</div>';">
                   </iframe>`;
        } else {
            html = '暂不支持该类型文件预览';
        }
        document.getElementById('previewBody').innerHTML = html;
        var modal = new bootstrap.Modal(document.getElementById('previewModal'));
        modal.show();
    }
    // 内联新建文件夹
    const fileTableBody = document.getElementById('fileTableBody');
    document.getElementById('inlineMkdirBtn').onclick = function() {
        if (document.getElementById('inlineMkdirRow')) return;
        const tr = document.createElement('tr');
        tr.id = 'inlineMkdirRow';
        tr.innerHTML = `<td colspan='7'><div class='d-flex align-items-center'><i class='bi bi-folder2-open text-warning me-2'></i><input type='text' class='form-control' id='inlineMkdirInput' style='max-width:220px;display:inline-block;' value='新建文件夹' autofocus><button class='btn btn-primary btn-sm ms-2' id='inlineMkdirOk'>确定</button><button class='btn btn-link btn-sm text-secondary' id='inlineMkdirCancel'>取消</button></div></td>`;
        fileTableBody.prepend(tr);
        const input = document.getElementById('inlineMkdirInput');
        input.focus();
        input.select();
        function submitMkdir() {
            const name = input.value.trim();
            if (!name) { input.focus(); return; }
            const formData = new FormData();
            formData.append('name', name);
            formData.append('dir', <?= json_encode($dir) ?>);
            fetch('?c=File&a=mkdir', {method:'POST', body:formData}).then(r=>{
                if (r.redirected) { window.location = r.url; }
                else r.text().then(alert);
            });
        }
        input.onkeydown = function(e) {
            if (e.key === 'Enter') submitMkdir();
            if (e.key === 'Escape') tr.remove();
        };
        document.getElementById('inlineMkdirOk').onclick = submitMkdir;
        document.getElementById('inlineMkdirCancel').onclick = () => tr.remove();
        input.onblur = function() { setTimeout(()=>{ if(document.activeElement!==document.getElementById('inlineMkdirOk')) tr.remove(); }, 200); };
    };
    // 内联新建文件
    document.getElementById('inlineCreateFileBtn').onclick = function() {
        if (document.getElementById('inlineCreateFileRow')) return;
        const tr = document.createElement('tr');
        tr.id = 'inlineCreateFileRow';
        tr.innerHTML = `
        <td colspan='7'>
            <div class='card p-3'>
                <div class='d-flex align-items-center mb-2'>
                    <i class='bi bi-file-earmark text-info me-2'></i>
                    <input type='text' class='form-control' id='inlineCreateFileName' style='max-width:220px;' placeholder='文件名' autofocus>
                    <small class="text-muted ms-2">例如: example.txt, script.js</small>
                </div>
                <div class='mb-2'>
                    <textarea class='form-control' id='inlineCreateFileContent' rows='5' placeholder='文件内容...'></textarea>
                </div>
                <div>
                    <button class='btn btn-primary btn-sm' id='inlineCreateFileOk'>创建</button>
                    <button class='btn btn-link btn-sm text-secondary' id='inlineCreateFileCancel'>取消</button>
                </div>
            </div>
        </td>`;
        fileTableBody.prepend(tr);
        const nameInput = document.getElementById('inlineCreateFileName');
        nameInput.focus();
        
        function submitCreateFile() {
            const name = nameInput.value.trim();
            const content = document.getElementById('inlineCreateFileContent').value;
            if (!name) { nameInput.focus(); return; }
            
            const formData = new FormData();
            formData.append('name', name);
            formData.append('content', content);
            formData.append('dir', <?= json_encode($dir) ?>);
            
            fetch('?c=File&a=createFile', {
                method: 'POST',
                body: formData
            }).then(r => {
                if (r.redirected) {
                    window.location = r.url;
                } else {
                    r.json().then(data => {
                        alert(data.message || '操作失败');
                    });
                }
            });
        }
        
        document.getElementById('inlineCreateFileOk').onclick = submitCreateFile;
        document.getElementById('inlineCreateFileCancel').onclick = () => tr.remove();
        nameInput.onkeydown = function(e) {
            if (e.key === 'Enter') submitCreateFile();
            if (e.key === 'Escape') tr.remove();
        };
    };
    // 多选模式
    let multiMode = false, copyList = [], cutList = [], opType = '';
    const multiBtn = document.getElementById('multiSelectBtn');
    const batchBar = document.getElementById('batchBar');
    const multiTh = document.getElementById('multiSelectTh');
    const multiCancel = document.getElementById('multiSelectCancel');
    const multiAll = document.getElementById('multiSelectAll');
    function setMultiMode(on) {
        multiMode = on;
        document.querySelectorAll('.multiSelectTd').forEach(td=>td.style.display=on?'':'none');
        multiTh.style.display = on ? '' : 'none';
        batchBar.style.display = on ? '' : 'none';
        if (!on) document.querySelectorAll('.multiSelectCk').forEach(ck=>ck.checked=false);
        document.getElementById('batchCount').innerText = '';
    }
    multiBtn.onclick = ()=>setMultiMode(true);
    multiCancel.onclick = ()=>setMultiMode(false);
    multiAll.onclick = function(){
        document.querySelectorAll('.multiSelectCk').forEach(ck=>ck.checked=multiAll.checked);
        updateBatchCount();
    };
    document.querySelectorAll('.multiSelectCk').forEach(ck=>{
        ck.onchange = updateBatchCount;
    });
    function updateBatchCount() {
        const checked = document.querySelectorAll('.multiSelectCk:checked');
        document.getElementById('batchCount').innerText = checked.length ? `已选${checked.length}项` : '';
        multiAll.checked = checked.length && checked.length === document.querySelectorAll('.multiSelectCk').length;
    }
    // 文件行点击预览/文件夹行点击跳转（非功能区）
    document.querySelectorAll('.file-row').forEach(row => {
        row.addEventListener('click', function(e) {
            if (e.target.closest('.op-btn')) return;
            if (this.dataset.isdir === '1') {
                // 是文件夹，跳转
                location.href = '?c=File&a=index&dir=' + encodeURIComponent(this.dataset.dir);
            } else if (this.querySelector('td:nth-child(3)').innerText.trim() === '文件') {
                // 是文件，预览
                previewFile(this.dataset.file, this.dataset.name);
            }
        });
    });
    // 操作区按钮阻止冒泡（保险）
    document.querySelectorAll('.op-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    });
    let quill = null;
    function editFile(path, name) {
        // 判断扩展名
        const ext = name.split('.').pop().toLowerCase();
        const richExts = ['txt','md','html'];
        const isRich = richExts.includes(ext);
        
        console.log('编辑文件:', path, name); // 添加调试日志

        fetch('?c=File&a=edit&path=' + encodeURIComponent(path))
            .then(r => {
                console.log('编辑请求状态:', r.status);
                return r.json();
            })
            .then(data => {
                console.log('编辑响应数据:', data);
                if (!data.success) {
                    alert(data.message || '无法读取文件');
                    return;
                }
                document.getElementById('editFileName').innerText = name;
                document.getElementById('editFilePath').value = path;

                if (isRich) {
                    document.getElementById('editFileContent').style.display = 'none';
                    document.getElementById('quillEditor').style.display = '';
                    // 初始化Quill
                    if (!quill) {
                        quill = new Quill('#quillContent', {
                            modules: { toolbar: [
                                ['bold', 'italic', 'underline', 'strike'],
                                [{ 'color': [] }, { 'background': [] }],
                                [{ 'font': [] }, { 'size': [] }],
                                [{ 'align': [] }],
                                ['clean']
                            ]},
                            theme: 'snow'
                        });
                    }
                    quill.setText(''); // 清空
                    quill.clipboard.dangerouslyPasteHTML(data.content);
                } else {
                    document.getElementById('quillEditor').style.display = 'none';
                    document.getElementById('editFileContent').style.display = '';
                    document.getElementById('editFileContent').value = data.content;
                }
                var modal = new bootstrap.Modal(document.getElementById('editModal'));
                modal.show();
            })
            .catch(error => {
                console.error('编辑文件请求错误:', error);
                alert('编辑请求失败: ' + error.message);
            });
    }
    document.getElementById('editFileSave').onclick = function() {
        const name = document.getElementById('editFileName').innerText;
        const ext = name.split('.').pop().toLowerCase();
        const richExts = ['txt','md','html'];
        const isRich = richExts.includes(ext);

        const path = document.getElementById('editFilePath').value;
        let content = '';
        if (isRich) {
            content = quill.root.innerHTML;
        } else {
            content = document.getElementById('editFileContent').value;
        }
        
        // 显示保存中状态
        this.disabled = true;
        this.innerText = '保存中...';
        
        fetch('?c=File&a=edit', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'path=' + encodeURIComponent(path) + '&content=' + encodeURIComponent(content)
        })
        .then(r => {
            if (!r.ok) {
                throw new Error('服务器返回错误: ' + r.status);
            }
            return r.json();
        })
        .then(data => {
            if (data.success) {
                // 创建一个临时消息提示保存成功
                let msgDiv = document.createElement('div');
                msgDiv.className = 'position-fixed top-0 start-50 translate-middle-x p-3 mt-4';
                msgDiv.style.zIndex = '9999';
                msgDiv.innerHTML = `
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        文件保存成功
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="关闭"></button>
                    </div>
                `;
                document.body.appendChild(msgDiv);
                setTimeout(() => {
                    msgDiv.querySelector('.alert').classList.remove('show');
                    setTimeout(() => msgDiv.remove(), 300);
                }, 2000);
                
                // 关闭编辑窗口
                bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
            } else {
                alert('保存失败: ' + (data.message || '未知错误'));
            }
        })
        .catch(error => {
            console.error('保存文件请求错误:', error);
            alert('保存请求失败: ' + error.message);
        })
        .finally(() => {
            // 恢复按钮状态
            this.disabled = false;
            this.innerText = '保存';
        });
    };
    function showPermissions(path, name, isDir) {
        document.getElementById('permissionsPath').value = path;
        document.getElementById('permissionsIsDir').value = isDir;
        document.getElementById('permissionsFileName').innerText = name;
        
        // 重置表单
        document.getElementById('permPublicReadable').checked = false;
        document.getElementById('permPublicWritable').checked = false;
        document.getElementById('permSharedUsers').value = '';
        document.getElementById('permShareReadable').checked = false;
        document.getElementById('permShareWritable').checked = false;
        document.getElementById('permInherit').checked = true;
        
        // 清除可能存在的错误或警告信息
        const existingAlerts = document.querySelectorAll('#permissionsModal .modal-body .alert');
        existingAlerts.forEach(alert => alert.remove());
        
        // 加载现有权限设置
        fetch('?c=File&a=getPermissions&path=' + encodeURIComponent(path))
        .then(r => {
            if (!r.ok) {
                throw new Error('服务器返回错误: ' + r.status);
            }
            return r.json();
        })
        .then(data => {
            if (data.success && data.permissions) {
                const perms = data.permissions;
                document.getElementById('permPublicReadable').checked = perms.public_read == 1;
                document.getElementById('permPublicWritable').checked = perms.public_write == 1;
                document.getElementById('permSharedUsers').value = perms.shared_users || '';
                document.getElementById('permShareReadable').checked = perms.shared_read == 1;
                document.getElementById('permShareWritable').checked = perms.shared_write == 1;
                document.getElementById('permInherit').checked = perms.inherit_permissions == 1;
                
                // 如果有权限ID但不是自己设置的显示继承来源
                if (perms.id && window.location.href.indexOf(perms.file_path) === -1) {
                    const warning = document.createElement('div');
                    warning.className = 'alert alert-info mt-2 mb-2';
                    warning.innerHTML = `<small>当前权限继承自上级目录</small>`;
                    document.querySelector('#permissionsModal .modal-body').insertBefore(
                        warning, document.querySelector('#permissionsModal .modal-body').firstChild
                    );
                }
            }
        })
        .catch(error => {
            console.error('加载权限错误:', error);
            // 显示错误提示
            const errorMsg = document.createElement('div');
            errorMsg.className = 'alert alert-danger';
            errorMsg.innerText = '加载权限失败: ' + error.message;
            document.querySelector('#permissionsModal .modal-body').insertBefore(
                errorMsg, document.querySelector('#permissionsModal .modal-body').firstChild
            );
        });
        
        var modal = new bootstrap.Modal(document.getElementById('permissionsModal'));
        modal.show();
    }
    </script>
    <!-- 自定义确认 Modal（放在所有 <script> 之后，</body> 之前） -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="confirmModalLabel">操作确认</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="关闭"></button>
          </div>
          <div class="modal-body" id="confirmModalBody">确定要执行此操作吗？</div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="button" class="btn btn-primary" id="confirmModalOk">确定</button>
          </div>
        </div>
      </div>
    </div>
</div>
</body>
</html> 