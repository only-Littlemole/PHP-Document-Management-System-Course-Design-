<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Littlemole 文件管理系统' ?></title>
    <link href="https://cdnjs.loli.net/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body { background: #f6f8fa; }
        .main-layout { min-height: 100vh; display: flex; flex-direction: column; }
        .main-header { background: #1976d2; color: #fff; height: 56px; display: flex; align-items: center; justify-content: space-between; padding: 0 2rem; }
        .main-header .logo { font-size: 1.3rem; font-weight: 700; letter-spacing: 1px; display: flex; align-items: center; }
        .main-header .logo i { font-size: 2rem; margin-right: 0.5rem; }
        .main-header .user-info { font-size: 1rem; }
        .main-sidebar { width: 210px; background: #fff; border-right: 1px solid #e3e8ee; min-height: calc(100vh - 56px); padding-top: 1.5rem; }
        .main-sidebar .nav-link { color: #1976d2; font-weight: 500; border-radius: 8px; margin-bottom: 0.5rem; }
        .main-sidebar .nav-link.active, .main-sidebar .nav-link:hover { background: #e3f2fd; color: #125ea7; }
        .main-content { flex: 1; padding: 2.5rem 2rem; background: #f6f8fa; }
        @media (max-width: 900px) {
            .main-layout { flex-direction: column; }
            .main-sidebar { width: 100%; min-height: auto; border-right: none; border-bottom: 1px solid #e3e8ee; display: flex; flex-direction: row; padding: 0.5rem 0; }
            .main-sidebar .nav { flex-direction: row; width: 100%; justify-content: space-around; }
            .main-content { padding: 1.2rem 0.5rem; }
        }
    </style>
</head>
<body>
<div class="main-layout">
    <div class="main-header">
        <div class="logo"><i class="bi bi-folder2-open"></i> Littlemole 文件管理系统</div>
        <div class="user-info">
            <?php if (!empty($_SESSION['user'])): ?>
                <i class="bi bi-person-circle"></i> <?= htmlspecialchars($_SESSION['user']['username']) ?>
                <a href="?c=Auth&a=logout" class="text-white ms-3">退出</a>
            <?php endif; ?>
        </div>
    </div>
    <div style="display:flex;flex:1;">
        <nav class="main-sidebar">
            <ul class="nav flex-column w-100">
                <li class="nav-item"><a class="nav-link<?= ($_GET['c'] ?? '') === 'Dashboard' ? ' active' : '' ?>" href="?c=Dashboard&a=index"><i class="bi bi-speedometer2 me-2"></i>仪表盘</a></li>
                <li class="nav-item"><a class="nav-link<?= ($_GET['c'] ?? '') === 'File' ? ' active' : '' ?>" href="?c=File&a=index"><i class="bi bi-folder2-open me-2"></i>文件管理</a></li>
                <li class="nav-item"><a class="nav-link<?= ($_GET['c'] ?? '') === 'User' ? ' active' : '' ?>" href="#"><i class="bi bi-person me-2"></i>用户中心</a></li>
            </ul>
        </nav>
        <main class="main-content w-100">
            <?= $content ?? '' ?>
        </main>
    </div>
</div>
</body>
</html> 