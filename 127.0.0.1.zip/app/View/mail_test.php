<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>邮件发送测试 - Littlemole 文件管理系统</title>
    <link href="https://cdnjs.loli.net/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f6f8fa; }
        .mailtest-card { max-width: 420px; margin: 60px auto; box-shadow: 0 4px 24px rgba(25,118,210,0.10); border-radius: 18px; background: #fff; padding: 2.5rem 2rem 2rem 2rem; }
        .mailtest-title { font-weight: 700; font-size: 1.3rem; color: #1976d2; margin-bottom: 1.2rem; text-align: center; }
    </style>
</head>
<body>
<div class="container">
    <div class="mailtest-card">
        <div class="mailtest-title">临时邮件发送测试</div>
        <?php if (!empty($result)): ?>
            <div class="alert alert-info"> <?= htmlspecialchars($result) ?> </div>
        <?php endif; ?>
        <form method="post" autocomplete="off">
            <div class="mb-3">
                <label for="to" class="form-label">收件人邮箱</label>
                <input type="email" class="form-control" id="to" name="to" required>
            </div>
            <div class="mb-3">
                <label for="subject" class="form-label">主题</label>
                <input type="text" class="form-control" id="subject" name="subject" required>
            </div>
            <div class="mb-3">
                <label for="body" class="form-label">正文</label>
                <textarea class="form-control" id="body" name="body" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary w-100">发送测试邮件</button>
        </form>
        <div class="text-center mt-3">
            <a href="?c=File&a=index">返回首页</a>
        </div>
    </div>
</div>
</body>
</html> 