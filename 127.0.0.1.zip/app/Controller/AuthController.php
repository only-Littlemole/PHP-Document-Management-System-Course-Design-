<?php
namespace Controller;

use Service\AuthService;
use Service\MailService;

class AuthController
{
    public function welcomeAction()
    {
        include __DIR__ . '/../View/welcome.php';
    }

    public function loginAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            $auth = new AuthService();
            $result = $auth->login($username, $password);
            if ($result['success']) {
                header('Location: ?c=Dashboard&a=index');
                exit;
            } else {
                $error = $result['message'];
            }
        }
        include __DIR__ . '/../View/login.php';
    }

    public function registerAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $emailCode = trim($_POST['email_code'] ?? '');
            $captcha = trim($_POST['captcha'] ?? '');
            // 校验图形验证码
            if (empty($_SESSION['register_captcha']) || strtolower($captcha) !== strtolower($_SESSION['register_captcha'])) {
                $error = '图形验证码错误';
            } elseif (empty($_SESSION['register_email_code']) || empty($_SESSION['register_email']) ||
                $_SESSION['register_email'] !== $email || $_SESSION['register_email_code'] !== $emailCode) {
                $error = '邮箱验证码错误或已过期';
            } else {
                $auth = new AuthService();
                $result = $auth->register($username, $email, $password);
                if ($result['success']) {
                    unset($_SESSION['register_email_code'], $_SESSION['register_email'], $_SESSION['register_captcha']);
                    header('Location: ?c=Auth&a=login');
                    exit;
                } else {
                    $error = $result['message'];
                }
            }
        }
        include __DIR__ . '/../View/register.php';
    }

    // AJAX发送邮箱验证码
    public function sendEmailCodeAction()
    {
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => '邮箱格式不正确']);
            exit;
        }
        // 生成验证码
        $code = strval(rand(100000, 999999));
        $_SESSION['register_email_code'] = $code;
        $_SESSION['register_email'] = $email;
        $_SESSION['register_email_code_time'] = time();
        // 发送邮件
        $config = require __DIR__ . '/../Config/Mail.php';
        $mail = new MailService($config);
        $subject = '【Littlemole】注册验证码';
        $body = '您的注册验证码为：<b>' . $code . '</b>，有效期5分钟。';
        $result = $mail->send($email, $subject, $body);
        if ($result === true) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => $result]);
        }
        exit;
    }

    public function forgotPasswordAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $auth = new AuthService();
            $result = $auth->sendReset($email);
            $message = $result['message'];
        }
        include __DIR__ . '/../View/forgot_password.php';
    }

    // 图形验证码接口
    public function captchaAction()
    {
        header('Content-Type: image/png');
        $code = '';
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        for ($i = 0; $i < 4; $i++) {
            $code .= $chars[rand(0, strlen($chars) - 1)];
        }
        $_SESSION['register_captcha'] = $code;
        $im = imagecreatetruecolor(90, 36);
        $bg = imagecolorallocate($im, 245, 248, 250);
        imagefilledrectangle($im, 0, 0, 90, 36, $bg);
        $fontColor = imagecolorallocate($im, 25, 118, 210);
        $font = __DIR__ . '/../../public/assets/fonts/arial.ttf';
        if (!file_exists($font)) $font = __DIR__ . '/../../public/assets/fonts/simhei.ttf';
        if (!file_exists($font)) $font = null;
        for ($i = 0; $i < 4; $i++) {
            $angle = rand(-18, 18);
            $x = 15 + $i * 20;
            $y = rand(24, 32);
            if ($font) {
                imagettftext($im, 18, $angle, $x, $y, $fontColor, $font, $code[$i]);
            } else {
                imagestring($im, 5, $x, $y-18, $code[$i], $fontColor);
            }
        }
        // 干扰线
        for ($i = 0; $i < 3; $i++) {
            $lineColor = imagecolorallocate($im, rand(100,200), rand(100,200), rand(100,200));
            imageline($im, rand(0,90), rand(0,36), rand(0,90), rand(0,36), $lineColor);
        }
        imagepng($im);
        imagedestroy($im);
        exit;
    }

    // 退出登录
    public function logoutAction()
    {
        session_start();
        session_unset();
        session_destroy();
        header('Location: ?c=Auth&a=login');
        exit;
    }
} 