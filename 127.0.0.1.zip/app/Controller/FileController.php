<?php
namespace Controller;

use Model\FilePermission;

class FileController
{
    /**
     * 文件管理首页，展示文件列表
     */
    public function indexAction()
    {
        if (empty($_SESSION['user'])) {
            header('Location: ?c=Auth&a=welcome');
            exit;
        }
        $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
        $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
        // 自动创建用户根目录
        if (!is_dir($userRoot)) {
            mkdir($userRoot, 0777, true);
        }
        // 只允许在用户目录下浏览
        $dir = $_GET['dir'] ?? $userRoot;
        $realUserRoot = realpath($userRoot);
        $realDir = realpath($dir);
        if (!$realDir || strpos($realDir, $realUserRoot) !== 0) {
            $dir = $userRoot;
            $realDir = $realUserRoot;
        }
        if (!$realDir || !is_dir($realDir)) {
            $realDir = $userRoot;
        }
        $files = scandir($realDir);
        $fileList = array_filter($files, function($f) { return $f !== '.' && $f !== '..'; });
        $message = $_GET['msg'] ?? '';
        ob_start();
        include __DIR__ . '/../View/file_index.php';
        $content = ob_get_clean();
        $title = '文件管理';
        include __DIR__ . '/../View/layout.php';
    }

    // 新建文件夹
    public function mkdirAction()
    {
        if (empty($_SESSION['user'])) exit('未登录');
        $name = trim($_POST['name'] ?? '');
        $dir = $_POST['dir'] ?? '';
        $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
        $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
        $realUserRoot = realpath($userRoot);
        $realDir = realpath($dir);
        if (!$realDir || strpos($realDir, $realUserRoot) !== 0) exit('无权限');
        if (!$name || preg_match('/[\\\/\:\*\?\"\<\>\|]/', $name)) exit('文件夹名非法');
        $newPath = $realDir . DIRECTORY_SEPARATOR . $name;
        if (is_dir($newPath)) exit('文件夹已存在');
        if (mkdir($newPath, 0777, true)) {
            header('Location: ?c=File&a=index&dir=' . urlencode($realDir) . '&msg=新建成功');
        } else {
            exit('创建失败');
        }
    }

    // 删除文件/文件夹
    public function deleteAction()
    {
        if (empty($_SESSION['user'])) exit('未登录');
        $path = $_POST['path'] ?? '';
        $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
        $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
        $realUserRoot = realpath($userRoot);
        $realPath = realpath($path);
        if (!$realPath || strpos($realPath, $realUserRoot) !== 0) exit('无权限');
        if (is_dir($realPath)) {
            $it = new \RecursiveDirectoryIterator($realPath, \FilesystemIterator::SKIP_DOTS);
            $files = new \RecursiveIteratorIterator($it, \RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($files as $file) {
                $file->isDir() ? rmdir($file->getPathname()) : unlink($file->getPathname());
            }
            rmdir($realPath);
        } else {
            unlink($realPath);
        }
        header('Location: ?c=File&a=index&dir=' . urlencode(dirname($realPath)) . '&msg=删除成功');
    }

    // 重命名
    public function renameAction()
    {
        if (empty($_SESSION['user'])) exit('未登录');
        $path = $_POST['path'] ?? '';
        $newName = trim($_POST['new_name'] ?? '');
        $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
        $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
        $realUserRoot = realpath($userRoot);
        $realPath = realpath($path);
        if (!$realPath || strpos($realPath, $realUserRoot) !== 0) exit('无权限');
        if (!$newName || preg_match('/[\\\/\:\*\?\"\<\>\|]/', $newName)) exit('新名称非法');
        $newPath = dirname($realPath) . DIRECTORY_SEPARATOR . $newName;
        if (file_exists($newPath)) exit('目标已存在');
        if (rename($realPath, $newPath)) {
            header('Location: ?c=File&a=index&dir=' . urlencode(dirname($newPath)) . '&msg=重命名成功');
        } else {
            exit('重命名失败');
        }
    }

    // 上传文件
    public function uploadAction()
    {
        if (empty($_SESSION['user'])) exit('未登录');
        $dir = $_POST['dir'] ?? '';
        $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
        $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
        $realUserRoot = realpath($userRoot);
        $realDir = realpath($dir);
        if (!$realDir || strpos($realDir, $realUserRoot) !== 0) exit('无权限');
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) exit('上传失败');
        $name = $_FILES['file']['name'];
        if (preg_match('/[\\\/\:\*\?\"\<\>\|]/', $name)) exit('文件名非法');
        $target = $realDir . DIRECTORY_SEPARATOR . $name;
        if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
            header('Location: ?c=File&a=index&dir=' . urlencode($realDir) . '&msg=上传成功');
        } else {
            exit('保存失败');
        }
    }

    // 新建文件
    public function createFileAction()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            exit('方法不允许');
        }

        $name = trim($_POST['name'] ?? '');
        $content = $_POST['content'] ?? '';
        $dir = $_POST['dir'] ?? '';
        
        if (empty($name) || empty($dir)) {
            echo json_encode(['success' => false, 'message' => '参数错误']);
            exit;
        }
        
        // 安全检查
        if (strpos($name, '/') !== false || strpos($name, '\\') !== false) {
            echo json_encode(['success' => false, 'message' => '文件名不能包含路径']);
            exit;
        }

        $filePath = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . $name;
        
        // 检查文件是否已存在
        if (file_exists($filePath)) {
            echo json_encode(['success' => false, 'message' => '文件已存在']);
            exit;
        }
        
        // 写入文件
        if (file_put_contents($filePath, $content) !== false) {
            header('Location: ?c=File&a=index&dir=' . urlencode($dir));
        } else {
            echo json_encode(['success' => false, 'message' => '创建文件失败']);
        }
        exit;
    }

    /**
     * 编辑文件内容
     * 
     * GET方式获取文件内容，POST方式保存文件内容
     */
    public function editAction()
    {
        // 设置响应头为JSON
        header('Content-Type: application/json');
        
        try {
            if (empty($_SESSION['user'])) {
                echo json_encode(['success' => false, 'message' => '未登录']);
                exit;
            }
    
            $path = $_REQUEST['path'] ?? '';
            if (empty($path)) {
                echo json_encode(['success' => false, 'message' => '缺少路径参数']);
                exit;
            }
            
            $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
            $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
            $realUserRoot = realpath($userRoot);
            $realPath = realpath($path);
    
            // 安全检查
            if (!$realPath || strpos($realPath, $realUserRoot) !== 0) {
                echo json_encode(['success' => false, 'message' => '无权限访问此文件']);
                exit;
            }
    
            if (!is_file($realPath)) {
                echo json_encode(['success' => false, 'message' => '文件不存在或不是普通文件']);
                exit;
            }
    
            // GET请求读取文件内容
            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                $content = file_get_contents($realPath);
                if ($content === false) {
                    echo json_encode(['success' => false, 'message' => '无法读取文件内容']);
                    exit;
                }
                echo json_encode(['success' => true, 'content' => $content]);
                exit;
            } 
            // POST请求保存文件内容
            else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $content = $_POST['content'] ?? '';
                if (file_put_contents($realPath, $content) !== false) {
                    echo json_encode(['success' => true, 'message' => '保存成功']);
                } else {
                    echo json_encode(['success' => false, 'message' => '保存失败']);
                }
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => '不支持的请求方法']);
                exit;
            }
        } catch (\Exception $e) {
            // 捕获所有异常并返回JSON格式错误
            echo json_encode(['success' => false, 'message' => '处理请求时出错: ' . $e->getMessage()]);
            exit;
        }
    }

    /**
     * 设置文件权限
     */
    public function setPermissionsAction()
    {
        if (empty($_SESSION['user'])) {
            header('Location: ?c=Auth&a=welcome');
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ?c=File&a=index');
            exit;
        }
        
        $path = $_POST['path'] ?? '';
        $isDir = (int)($_POST['isDir'] ?? 0);
        $permissions = $_POST['permissions'] ?? [];
        
        // 路径安全检查
        $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
        $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
        $realUserRoot = realpath($userRoot);
        $realPath = realpath($path);
        
        if (!$realPath || strpos($realPath, $realUserRoot) !== 0) {
            header('Location: ?c=File&a=index&msg=' . urlencode('无权限修改此文件'));
            exit;
        }
        
        // 处理权限设置
        try {
            // 设置执行时间限制和内存限制
            ini_set('max_execution_time', 30);
            ini_set('memory_limit', '256M');
            
            $permModel = new FilePermission();
            $permModel->setPermissions(
                $_SESSION['user']['id'],
                $realPath,
                [
                    'public_read' => isset($permissions['public_read']) ? 1 : 0,
                    'public_write' => isset($permissions['public_write']) ? 1 : 0,
                    'shared_users' => $permissions['shared_users'] ?? null,
                    'shared_read' => isset($permissions['shared_read']) ? 1 : 0,
                    'shared_write' => isset($permissions['shared_write']) ? 1 : 0,
                    'inherit' => isset($permissions['inherit']) ? 1 : 0
                ],
                $isDir
            );
            
            $dirParam = urlencode(dirname($realPath));
            header('Location: ?c=File&a=index&dir=' . $dirParam . '&msg=' . urlencode('权限设置成功'));
        } catch (\Exception $e) {
            header('Location: ?c=File&a=index&msg=' . urlencode('权限设置失败: ' . $e->getMessage()));
        }
        exit;
    }

    /**
     * 加载现有权限设置（Ajax）
     */
    public function getPermissionsAction()
    {
        header('Content-Type: application/json');
        
        if (empty($_SESSION['user'])) {
            echo json_encode(['success' => false, 'message' => '未登录']);
            exit;
        }
        
        $path = $_GET['path'] ?? '';
        
        if (empty($path)) {
            echo json_encode(['success' => false, 'message' => '路径参数缺失']);
            exit;
        }
        
        // 路径安全检查
        $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
        $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
        $realUserRoot = realpath($userRoot);
        $realPath = realpath($path);
        
        if (!$realPath || strpos($realPath, $realUserRoot) !== 0) {
            echo json_encode(['success' => false, 'message' => '无权限访问此文件']);
            exit;
        }
        
        // 获取权限
        try {
            // 设置执行时间限制和内存限制
            ini_set('max_execution_time', 30);
            ini_set('memory_limit', '256M');
            
            $permModel = new FilePermission();
            $perms = $permModel->getPermissions($_SESSION['user']['id'], $realPath);
            
            echo json_encode([
                'success' => true,
                'permissions' => $perms
            ]);
        } catch (\Exception $e) {
            echo json_encode(['success' => false, 'message' => '获取权限失败: ' . $e->getMessage()]);
        }
        exit;
    }
} 