<?php
namespace Controller;

class FileAccessController
{
    public function getFileAction()
    {
        // 清理所有输出缓冲
        while (ob_get_level()) ob_end_clean();
        
        try {
            // 获取文件路径
            $filePath = urldecode($_GET['path'] ?? '');
            error_log("[FileAccess] 请求文件: $filePath");
            
            // 检查路径
            if (empty($filePath) || strpos($filePath, 'user_files/') !== 0) {
                throw new \Exception('无效的文件路径');
            }
            
            // 构建完整物理路径
            $fullPath = __DIR__ . '/../../' . $filePath;
            error_log("[FileAccess] 完整路径: $fullPath");
            
            // 检查文件是否存在
            if (!file_exists($fullPath) || is_dir($fullPath)) {
                throw new \Exception('文件不存在');
            }
            
            // 获取文件扩展名
            $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
            
            // 判断图片类型
            $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp']);
            
            // 关闭错误显示
            error_reporting(0);
            ini_set('display_errors', 0);
            
            // 设置适当的头
            if ($isImage) {
                switch ($ext) {
                    case 'jpg':
                    case 'jpeg':
                        header('Content-Type: image/jpeg');
                        break;
                    case 'png':
                        header('Content-Type: image/png');
                        break;
                    case 'gif':
                        header('Content-Type: image/gif');
                        break;
                    case 'webp':
                        header('Content-Type: image/webp');
                        break;
                    case 'bmp':
                        header('Content-Type: image/bmp');
                        break;
                    default:
                        header('Content-Type: application/octet-stream');
                }
                
                // 禁用缓存
                header('Cache-Control: no-cache, no-store, must-revalidate');
                header('Pragma: no-cache');
                header('Expires: 0');
                
                // 输出图片数据
                readfile($fullPath);
                exit;
            }
            else {
                // 其他文件类型
                $mime = $this->getMimeType($fullPath);
                header('Content-Type: ' . $mime);
                header('Content-Length: ' . filesize($fullPath));
                
                // 下载参数
                $isDownload = isset($_GET['download']) && $_GET['download'] === '1';
                if ($isDownload) {
                    header('Content-Disposition: attachment; filename="' . basename($fullPath) . '"');
                } else {
                    header('Content-Disposition: inline; filename="' . basename($fullPath) . '"');
                }
                
                readfile($fullPath);
                exit;
            }
        }
        catch (\Exception $e) {
            error_log("[FileAccess] 错误: " . $e->getMessage());
            header('Content-Type: text/plain');
            echo "文件访问错误: " . $e->getMessage();
            exit;
        }
    }
    
    private function getMimeType($file)
    {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $mimeMap = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
            'bmp' => 'image/bmp',
            'pdf' => 'application/pdf',
            'txt' => 'text/plain',
            'html' => 'text/html',
            'htm' => 'text/html',
            'css' => 'text/css',
            'js' => 'application/javascript',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'csv' => 'text/csv',
            'md' => 'text/markdown',
            'mp3' => 'audio/mpeg',
            'mp4' => 'video/mp4',
            'zip' => 'application/zip',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        ];
        
        return $mimeMap[$ext] ?? 'application/octet-stream';
    }
} 