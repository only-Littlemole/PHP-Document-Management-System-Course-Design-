<?php
namespace Controller;

use Service\DashboardService;

class DashboardController
{
    public function indexAction()
    {
        $service = new DashboardService();
        $stats = $service->getStats();
        include __DIR__ . '/../View/dashboard.php';
    }
} 