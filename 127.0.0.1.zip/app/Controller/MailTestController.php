<?php
namespace Controller;

use Service\MailService;

class MailTestController
{
    public function indexAction()
    {
        $result = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $to = trim($_POST['to'] ?? '');
            $subject = trim($_POST['subject'] ?? '');
            $body = trim($_POST['body'] ?? '');
            $config = require __DIR__ . '/../Config/Mail.php';
            $mail = new MailService($config);
            $send = $mail->send($to, $subject, $body);
            $result = $send === true ? '发送成功！' : ('发送失败：' . $send);
        }
        include __DIR__ . '/../View/mail_test.php';
    }
} 