<?php
namespace Service;

class AuthService
{
    private $pdo;
    public function __construct()
    {
        $config = require __DIR__ . '/../Config/Database.php';
        $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset={$config['charset']}";
        $this->pdo = new \PDO($dsn, $config['user'], $config['pass']);
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
    }

    public function login(string $username, string $password): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE username = :username');
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email']
            ];
            return ['success' => true];
        }
        return ['success' => false, 'message' => '用户名或密码错误'];
    }

    public function register(string $username, string $email, string $password): array
    {
        if (strlen($username) < 3 || strlen($password) < 6) {
            return ['success' => false, 'message' => '用户名或密码长度不符合要求'];
        }
        $stmt = $this->pdo->prepare('SELECT id FROM users WHERE username = :username OR email = :email');
        $stmt->execute(['username' => $username, 'email' => $email]);
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => '用户名或邮箱已存在'];
        }
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->pdo->prepare('INSERT INTO users (username, email, password, created_at, updated_at) VALUES (:username, :email, :password, NOW(), NOW())');
        $stmt->execute(['username' => $username, 'email' => $email, 'password' => $hash]);
        // 注册成功后创建用户文件夹
        $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
        $userDir = rtrim($userFilesConfig['root'], '/\\') . '/' . $email;
        if (!is_dir($userDir)) {
            mkdir($userDir, 0777, true);
        }
        return ['success' => true];
    }

    public function sendReset(string $email): array
    {
        // 伪实现：实际应发送邮件
        $stmt = $this->pdo->prepare('SELECT id FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        if ($stmt->fetch()) {
            return ['success' => true, 'message' => '重置链接已发送到邮箱（模拟）'];
        }
        return ['success' => false, 'message' => '邮箱未注册'];
    }
} 