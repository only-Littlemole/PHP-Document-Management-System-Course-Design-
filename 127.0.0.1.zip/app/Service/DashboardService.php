<?php
namespace Service;

class DashboardService
{
    public function getStats()
    {
        // 统计当前用户目录下的文件数和空间用量
        $fileCount = 0;
        $totalSize = 0;
        if (!empty($_SESSION['user'])) {
            $userFilesConfig = require __DIR__ . '/../Config/UserFiles.php';
            $userRoot = rtrim($userFilesConfig['root'], '/\\') . '/' . $_SESSION['user']['email'];
            if (is_dir($userRoot)) {
                $rii = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($userRoot));
                foreach ($rii as $file) {
                    if ($file->isFile()) {
                        $fileCount++;
                        $totalSize += $file->getSize();
                    }
                }
            }
        }
        // 统计用户数
        $userCount = 0;
        try {
            $config = require __DIR__ . '/../Config/Database.php';
            $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset={$config['charset']}";
            $pdo = new \PDO($dsn, $config['user'], $config['pass']);
            $stmt = $pdo->query('SELECT COUNT(*) FROM users');
            $userCount = (int)$stmt->fetchColumn();
        } catch (\Exception $e) {}
        return [
            'file_count' => $fileCount,
            'total_size' => $totalSize,
            'user_count' => $userCount,
        ];
    }
} 