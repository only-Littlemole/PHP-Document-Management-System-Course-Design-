<?php
namespace Service;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class MailService
{
    private $host;
    private $port;
    private $username;
    private $password;
    private $from;
    private $fromName;
    private $secure;

    public function __construct($config = [])
    {
        $this->host = $config['host'] ?? 'smtp.example.com';
        $this->port = $config['port'] ?? 465;
        $this->username = $config['username'] ?? '';
        $this->password = $config['password'] ?? '';
        $this->from = $config['from'] ?? '';
        $this->fromName = $config['from_name'] ?? '';
        $this->secure = $config['secure'] ?? 'ssl';
    }

    /**
     * 发送邮件（使用PHPMailer）
     * @param string $to 收件人邮箱
     * @param string $subject 邮件主题
     * @param string $body 邮件正文（支持HTML）
     * @return bool|string 成功返回true，失败返回错误信息
     */
    public function send($to, $subject, $body)
    {
        require_once __DIR__ . '/../../vendor/autoload.php';
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = $this->host;
            $mail->SMTPAuth = true;
            $mail->Username = $this->username;
            $mail->Password = $this->password;
            $mail->SMTPSecure = $this->secure;
            $mail->Port = $this->port;
            $mail->CharSet = 'UTF-8';
            $mail->setFrom($this->from, $this->fromName);
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;
            $mail->send();
            return true;
        } catch (Exception $e) {
            return $mail->ErrorInfo;
        }
    }
} 