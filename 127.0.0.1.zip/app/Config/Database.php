<?php
return [
    'host' => '127.0.0.1',
    'dbname' => 'file_management_system',
    'user' => 'root',
    'pass' => 'root',
    'charset' => 'utf8mb4',
]; 