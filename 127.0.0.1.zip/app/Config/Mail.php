<?php
return [
    'host' => 'smtp.qq.com', // SMTP服务器
    'port' => 465, // 端口
    'username' => '3420986576@qq.com', // SMTP账号
    'password' => 'oagnakfddoftdaeg', // SMTP密码
    'from' => '3420986576@qq.com', // 发件人邮箱
    'from_name' => 'Littlemole系统', // 发件人名称
    'secure' => 'ssl', // ssl或tls
]; 