<?php
return [
    'root' => dirname(__DIR__, 2) . '/user_files', // 用户文件根目录，和public平级
]; 