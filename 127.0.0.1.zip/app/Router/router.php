<?php
// 路由解析与分发
if (!isset($_GET['c']) && !isset($_GET['a'])) {
    session_start();
    if (isset($_SESSION['user_id'])) {
        header('Location: ?c=Dashboard&a=index');
        exit;
    }
}

$controller = $_GET['c'] ?? 'File';
$action = $_GET['a'] ?? 'index';

$controllerClass = 'Controller\\' . ucfirst($controller) . 'Controller';
$actionMethod = $action . 'Action';

try {
    if (class_exists($controllerClass)) {
        $ctrl = new $controllerClass();
        if (method_exists($ctrl, $actionMethod)) {
            $ctrl->$actionMethod();
        } else {
            throw new Exception('方法不存在: ' . $actionMethod);
        }
    } else {
        throw new Exception('控制器不存在: ' . $controllerClass);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo '<h1>系统错误</h1><p>' . htmlspecialchars($e->getMessage()) . '</p>';
} 