<?php
/**
 * 数据库初始化脚本
 * 用于创建数据库表和初始数据
 */

// 读取数据库配置
$config = require __DIR__ . '/app/Config/Database.php';
$dsn = "mysql:host={$config['host']};charset={$config['charset']}";

try {
    // 连接数据库
    $pdo = new PDO($dsn, $config['user'], $config['pass']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "连接数据库成功!\n";
    
    // 创建数据库
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$config['dbname']}` DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    echo "数据库 {$config['dbname']} 创建成功或已存在\n";
    
    // 选择数据库
    $pdo->exec("USE `{$config['dbname']}`");
    
    // 创建用户表
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `users` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `email` varchar(255) NOT NULL,
          `password` varchar(255) NOT NULL,
          `name` varchar(100) DEFAULT NULL,
          `activate_code` varchar(64) DEFAULT NULL,
          `reset_token` varchar(64) DEFAULT NULL,
          `reset_expires` datetime DEFAULT NULL,
          `status` tinyint(1) DEFAULT 0 COMMENT '0=未激活, 1=已激活',
          `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          UNIQUE KEY `email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "用户表创建成功\n";
    
    // 创建文件权限表
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `file_permissions` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `owner_id` int(11) NOT NULL,
          `file_path` varchar(512) NOT NULL,
          `is_directory` tinyint(1) DEFAULT 0,
          `public_read` tinyint(1) DEFAULT 0,
          `public_write` tinyint(1) DEFAULT 0,
          `shared_users` text DEFAULT NULL,
          `shared_read` tinyint(1) DEFAULT 0,
          `shared_write` tinyint(1) DEFAULT 0,
          `inherit_permissions` tinyint(1) DEFAULT 1,
          `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          UNIQUE KEY `owner_file` (`owner_id`, `file_path`(255)),
          KEY `owner_id` (`owner_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "文件权限表创建成功\n";
    
    echo "数据库初始化完成!\n";
    
} catch (PDOException $e) {
    die("数据库错误: " . $e->getMessage() . "\n");
}