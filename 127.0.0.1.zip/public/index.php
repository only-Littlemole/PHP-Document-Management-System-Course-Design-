<?php
// 严格类型声明
declare(strict_types=1);

session_start();

// 自动加载（可扩展为Composer自动加载）
spl_autoload_register(function ($class) {
    $file = __DIR__ . '/../app/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

require __DIR__ . '/../app/Router/router.php'; 